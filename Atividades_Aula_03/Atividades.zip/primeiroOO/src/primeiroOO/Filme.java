package primeiroOO;

public class Filme {
	public String titulo;
	public String diretor;
	public int anoLancamento;
	public String genero;
}
