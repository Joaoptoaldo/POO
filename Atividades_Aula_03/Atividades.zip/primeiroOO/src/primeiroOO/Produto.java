package primeiroOO;

public class Produto {
//	5 - Crie uma classe chamada Produto com os atributos:
//
//		•nome
//
//		•preço
//
//		•quantidadeEmEstoque
//
	public String nome;
	public double preco;
	public int quantidadeEmEstoque;
}
