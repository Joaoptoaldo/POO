package primeiroOO;

import java.util.Scanner;

public class executaAluno {
	//		•Crie uma classe executável que:
	//
	//		•Solicite os dados do aluno pelo teclado.
	//
	//		•Calcule a média das três notas.
	//
	//		•Exiba os dados do aluno e sua média.
	//
	//		•Mostre também se o aluno está:
	//
	//		•Aprovado (média >= 6)
	//
	//		•Reprovado (média < 6)
			Scanner leitor = new Scanner(System.in);
			
			int media = 0;
			
			Aluno aluno = new Aluno();
			
			System.out.println("Informe o nome do aluno: ");
		    aluno.nome = leitor.nextLine();
		    System.out.print("Informe a matricula: ");
		    aluno.matricula = leitor.nextInt();
		    leitor.nextLine();
		    System.out.print("Informe a nota 1: ");
		    aluno.matricula = leitor.nextInt();
		    leitor.nextLine();
		    System.out.print("Informe a nota 2: ");
		    aluno.matricula = leitor.nextInt();
		    leitor.nextLine();
		    System.out.print("Informe a nota 3: ");
		    aluno.matricula = leitor.nextInt();
		    leitor.nextLine();
		    
		    if(media >= 6) {
		    	System.out.println("Aprovado");
		    }
		    else {
		    	System.out.println("Reprovado");
		    }

	}
}
