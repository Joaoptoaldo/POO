package primeiroOO;

public class Livro {
	//4 - Crie uma classe Livro com os atributos 
	//título, autor e ano de publicação. Imprima as informações do livro na tela.
	
	public String titulo;
	public String autor;
	public int anoPubli;
}
